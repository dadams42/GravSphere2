###########################################################
#GravSphere 2
###########################################################

#from binulator_initialise_PlumCuspOm import *

from gravsphere_initialise_Draco import *

from line_profiles import *

from scipy.special import gamma

import numpy as np
import matplotlib.pyplot as plt
from matplotlib import rcParams
from multiprocessing import Pool
from multiprocessing import cpu_count
from scipy.integrate import simpson as integrator
#from scipy.integrate import simps as integrator
from constants import *
from gs2_functions import *

from numpy import percentile as pti

import scipy

pfits = np.array([42.0, (1/0.5**(2/3)-1)**(0.5) * 10.0 * 76 * 60.0 / arcsec, 2, 5, 0.0])

tracertol = 1e-6

nupars_min = np.zeros(len(pfits))
nupars_max = np.zeros(len(pfits))
nupars_minstart = np.zeros(len(pfits))
nupars_maxstart = np.zeros(len(pfits))
for i in range(len(pfits)):
    if (pfits[i] > 0):
        nupars_min[i] = pfits[i]*(1.0-tracertol)
        nupars_max[i] = pfits[i]*(1.0+tracertol)
    else:
        nupars_min[i] = pfits[i]*(1.0+tracertol)
        nupars_max[i] = pfits[i]*(1.0-tracertol)
    if (tracertol < 0.01):
        nupars_minstart[i] = nupars_min[i]
        nupars_maxstart[i] = nupars_max[i]
    else:
        if (pfits[i] > 0):
            nupars_minstart[i] = pfits[i]*0.99
            nupars_maxstart[i] = pfits[i]*1.01
        else:
            nupars_minstart[i] = pfits[i]*1.01
            nupars_maxstart[i] = pfits[i]*0.99

n_betpars = 4

#nu_components = len(pfits)

nu_components = 0

ndims =  2 * n_betpars + nu_components + 6 + 1 + 1

surc = pfits

minarr = np.zeros(ndims - 2)
maxarr = np.zeros(ndims - 2)
minarr[0] = bet0min
maxarr[0] = bet0max
minarr[1] = betinfmin
maxarr[1] = betinfmax
minarr[2] = betr0min
maxarr[2] = betr0max
minarr[3] = betnmin
maxarr[3] = betnmax

minarr[4] = bet0min
maxarr[4] = bet0max
minarr[5] = betinfmin
maxarr[5] = betinfmax
minarr[6] = betr0min
maxarr[6] = betr0max
minarr[7] = betnmin
maxarr[7] = betnmax

#minarr = np.delete(minarr, np.array([4, 5]))

logthis = [2, 6, 2*n_betpars+nu_components, 2*n_betpars+nu_components + 2, 2*n_betpars+nu_components+4, 2*n_betpars+nu_components+6]

#nupars_min[1:] = 0.1,2,5,0.1 - 1e-6

#nupars_max[1:] = 0.1,2,5,0.1 + 1e-6


lmst0 = (np.log10(3.2e5) + np.log10(6.2e5))/2.0
lmst0_err = ((np.log10(3.2e5) - lmst0)**2 + (np.log10(3.2e5) - lmst0)**2)**0.5 / 2**0.5

#minarr[2*n_betpars:2*n_betpars] = nupars_min
#maxarr[2*n_betpars:2*n_betpars] = nupars_max
minarr[2*n_betpars+nu_components] = logM200low
maxarr[2*n_betpars+nu_components] = logM200high
minarr[2*n_betpars+nu_components+1] = clow
maxarr[2*n_betpars+nu_components+1] = chigh
minarr[2*n_betpars+nu_components+2] = logrclow
maxarr[2*n_betpars+nu_components+2] = logrchigh
minarr[2*n_betpars+nu_components+3] = nlow
maxarr[2*n_betpars+nu_components+3] = nhigh
minarr[2*n_betpars+nu_components+4] = logrtlow
maxarr[2*n_betpars+nu_components+4] = logrthigh
minarr[2*n_betpars+nu_components+5] = dellow
maxarr[2*n_betpars+nu_components+5] = delhigh
#minarr[2*n_betpars+nu_components*2+6] = Mstar_min
#maxarr[2*n_betpars+nu_components*2+6] = Mstar_max
#minarr[2*n_betpars+nu_components*2+6] = logMcenlow
#maxarr[2*n_betpars+nu_components*2+6] = logMcenhigh
#minarr[n_betpars+nu_components*2+7] = acenlow
#maxarr[n_betpars+nu_components*2+7] = acenhigh
#minarr[n_betpars+nu_components*2+8] = Arotlow
#maxarr[n_betpars+nu_components*2+8] = Arothigh
#minarr[n_betpars+nu_components*2+9] = drangelow
#maxarr[n_betpars+nu_components*2+9] = drangehigh


def ptform(u):
    
    x = np.array(u)

    #x[4:8] = x[:4] * (1 - 1e-6) + x[:4] * 1e-6

    x[:-2] = minarr + (maxarr - minarr) * x[:-2]

    x[-2] = scipy.stats.norm.ppf(x[-2], loc = lmst0, scale = lmst0_err)

    x[-1] = scipy.stats.norm.ppf(x[-1], loc = 19.398, scale = 0.156)
    
    return x

if (barrad_min == 0):
        barrad_min = 1.0e-3
    
nu_rad = np.logspace(np.log10(barrad_min),\
                         np.log10(barrad_max), bar_pnts)

rhobs = alpbetgamden(nu_rad, *surc)

#bar_pnts = 1000
    
sobs = alpbetgamsurf(nu_rad, *surc, bar_pnts)

def baranr0(r):
        
        surf = np.interp(r,nu_rad,rhobs,right = 1e-30)
        
        return surf
    
def barsurf0(r):
        
        surf = np.interp(r,nu_rad,sobs,right = 1e-30)
        
        return surf

nusem = np.linspace(np.min(nu_rad), np.max(nu_rad), 10**4)

mobs = alpbetgammass(nusem, *surc)

#Hard coded for M62, photometric light profile here:
mlum = np.max(mobs)

mobs *= 1/mlum

def maser0(r, mst):
    
    #intpts = int(1e2)
    
    surf = mst * np.interp(r,nusem,mobs)
    
    return surf

def lnprob(Theta):
            
    theta = np.copy(Theta)

    theta[0]= 2.0*theta[0]/(1 + theta[0])

    theta[1] = 2.0*theta[1]/(1 + theta[1])

    theta[4]= 2.0*theta[4]/(1 + theta[4])

    theta[5] = 2.0*theta[5]/(1 + theta[5])

    d = 10.0**((theta[-1]  - 10.0)/5)

    surc = theta[2*n_betpars: 2*n_betpars+nu_components]

    for i in logthis:
        
        theta[i] = 10**theta[i]
    
   # mobs = alpbetgammass(nu_rad, *surc)
    
   # mlum = np.max(mobs)
    
   # mobs *= 1/mlum

    af = 1/(d/76.0)

    def baranr(r): 
    
        return af * baranr0(r * af)

    def barsurf(r):
        
        return barsurf0(r * af)

    def maser(r, mst):
    
        return maser0(r * af, mst) 
    
    def M(r, Mparsu):
    
        Mpars = np.copy(Mparsu)

        M200, c, rc, n, rt, delta, mst = Mpars

        return  corenfw_tides_mass(r,M200,c,rc,n,rt,delta) + maser(r, mst)

    Mpars = theta[2*n_betpars+nu_components:2*n_betpars+nu_components+6]

    mst = theta[-2]

    Mpars = np.append(Mpars, mst)

    betpars, betppars = theta[:4], theta[4:8]
    
    return lnlike_prop_k(baranr,barsurf,M,beta,betaf, Mpars,\
                 betpars, betppars, rmin, rmax, d)



aau = np.linspace(1e-6, 100, 10**4) # 1.8 < k < 3.0
kku = 3.0 - (2 * aau**4/15) * (1 + aau**2/3)**(-2)
def asolveu(k):

    return np.interp(k, kku[::-1], aau[::-1])  

def lukpdf(x, var, kurt, err):

        sigma = var**0.5

        w = (x)/sigma
        werr = err/sigma

        a = asolveu(kurt)

        b = ((1 + a**2/3))**0.5

        t = np.sqrt(1.+b*b*werr*werr)

        delta, w0 = 0.0, 0.0
        
        am, ap = a-delta, a+delta
        it = 1./t
        bw = b*(w-w0)

        ln_pdf  = np.log(.5*b/a)+np.where((b*w+a)*it<0.,
                       logdiffexp(log_ndtr((bw+a)*it),log_ndtr((bw-a)*it)),
                        logdiffexp(log_ndtr(-(bw-a)*it),log_ndtr(-(bw+a)*it)),
                      )
        ln_pdf -= np.log(sigma)
        
        return ln_pdf

aal = np.linspace(1e-6, 100, 10**4) # 3.0 < k < 6.0
kkl = 3.0 + 12 * aal**4 * (2 * aal**2 + 1)**(-2)
def asolvel(k):

    return np.interp(k, kkl, aal)
   

def llkpdf(x, var, kurt, err):

    sigma = var**0.5

    w = (x)/sigma
    werr = err/sigma

    a = asolvel(kurt)

    b = (2 * a**2 + 1)**0.5

    delta, mean_w  = 0.0, 0.0

    t = np.sqrt(1.+b*b*werr*werr)
    
    ap = a+delta
    am = a-delta
    
    argU = (t*t-2*ap*b*(w-mean_w))
    positive_term = np.zeros_like(x)
    
    prefactor = np.log(b/(4.*ap))
    if type(kurt) is np.ndarray:
        prefactor = prefactor[argU<0.]
    positive_term[argU<0.] = prefactor+(argU/2./ap**2)[argU<0.]+\
                                lnerfc(((t*t-ap*b*(w-mean_w))/np.sqrt(2)/t/ap)[argU<0.])
    
    prefactor = np.log(b/ap)
    if type(kurt) is np.ndarray:
        prefactor = prefactor[argU>0.]
    positive_term[argU>0.]=.5*np.log(np.pi/8.)+prefactor+lnalpha((b*(w-mean_w)/t)[argU>0.])+\
                            lnerfcx(((t*t-ap*b*(w-mean_w))/np.sqrt(2)/t/ap)[argU>0.])
    
    argU = (t*t+2*am*b*(w-mean_w))
    negative_term = np.zeros_like(x)
    
    prefactor = np.log(b/(4.*am))
    if type(kurt) is np.ndarray:
        prefactor = prefactor[argU<0.]
    negative_term[argU<0.] = prefactor+(argU/2./am**2)[argU<0.]+\
                                lnerfc(((t*t+am*b*(w-mean_w))/np.sqrt(2)/t/am)[argU<0.])
    prefactor = np.log(b/am)
    if type(kurt) is np.ndarray:
        prefactor = prefactor[argU>0.]
    negative_term[argU>0.]=.5*np.log(np.pi/8.)+prefactor+lnalpha((b*(w-mean_w)/t)[argU>0.])+\
                            lnerfcx(((t*t+am*b*(w-mean_w))/np.sqrt(2)/t/am)[argU>0.])
    
    ln_pdf = np.logaddexp(positive_term,negative_term)-np.log(sigma)

    return ln_pdf


def lnpdfj(x, var, kurt, err):

     return np.select([kurt < 3.0, kurt >= 3.0], [lukpdf(x, var, kurt, err), llkpdf(x, var, kurt, err)])

rLOS, vLOS, vLOS_err = np.loadtxt('dracoLOS.txt')

rPM, vPMt, vPMt_err, vPMR, vPMR_err = np.loadtxt('dracopms.txt')

rPM *= 76.0 / arcsec

def lnlike_prop_k(nu, Sigfunc,M,beta,betaf,Mpars,\
                 betpars, betppars, rmin,rmax, d):
    
    #theta = np.copy(Theta)
    
    Sigout, pmt2, pmr2, los2, kt, kr, kl = sigp_prop_k(np.array([1.0]),rLOS * d/76.0,rPM * d/76.0,nu,Sigfunc,M,beta,betaf,Mpars,\
                  betpars, betppars, rmin,rmax, nonn = 5.0)

    pmt2, pmr2, los2 = pmt2/1e6, pmr2/1e6, los2/1e6
    
    if np.isnan(np.sum(kl)) or np.isnan(np.sum(kt)) or np.isnan(np.sum(kr)):
    
        return -np.inf

    #kt, kr, kl = np.maximum(kt, 6.0), np.maximum(kr, 6.0), np.maximum(kl, 6.0) 

   # kt, kr, kl = np.minimum(kt, 1.8), np.minimum(kr, 1.8), np.minimum(kl, 1.8) 
    
    lnlike_out = np.sum(lnpdfj(vLOS, los2, kl, vLOS_err)) 
    lnlike_out += np.sum(lnpdfj(vPMt, pmt2 * (76.0/d)**2, kt, vPMt_err)) + \
    np.sum(lnpdfj(vPMR, pmr2 * (76.0/d)**2, kr, vPMR_err))
   # lnlike_out -= 0.5 * np.sum((surfden - Sigfunc(R))**2 / surfdenerr**2)

    if (lnlike_out != lnlike_out):
        lnlike_out = -np.inf
                    
    return lnlike_out


#Suppress warning output:
import warnings
warnings.simplefilter("ignore")

#Forbid plots to screen so GravSphere can run
#remotely:
import matplotlib as mpl
mpl.use('Agg')

