###########################################################
#GravSphere 2
###########################################################

from binulator_initialise_PlumCuspOm import *

from gravsphere_initialise_PlumCuspOm import *

from line_profiles import *

from scipy.special import gamma

import numpy as np
import matplotlib.pyplot as plt
from matplotlib import rcParams
from multiprocessing import Pool
from multiprocessing import cpu_count
from scipy.integrate import simpson as integrator
#from scipy.integrate import simps as integrator
from constants import *
from gs2_functions import *

from numpy import percentile as pti

import scipy

##            

#priors including prior transform implementation for dynesty

R, surfden, surfdenerr = np.loadtxt('photplumcusp.txt')

R, surfden, surfdenerr = R[:-1], surfden[:-1], surfdenerr[:-1]

pfits = np.array([203.7268193701383, 0.1, 2, 5, 0.1])
#pfits = np.array([13, 0.25,2,5,0.1]) 

nupars_min = np.zeros(len(pfits))
nupars_max = np.zeros(len(pfits))
nupars_minstart = np.zeros(len(pfits))
nupars_maxstart = np.zeros(len(pfits))
for i in range(len(pfits)):
    if (pfits[i] > 0):
        nupars_min[i] = pfits[i]*(1.0-tracertol)
        nupars_max[i] = pfits[i]*(1.0+tracertol)
    else:
        nupars_min[i] = pfits[i]*(1.0+tracertol)
        nupars_max[i] = pfits[i]*(1.0-tracertol)
    if (tracertol < 0.01):
        nupars_minstart[i] = nupars_min[i]
        nupars_maxstart[i] = nupars_max[i]
    else:
        if (pfits[i] > 0):
            nupars_minstart[i] = pfits[i]*0.99
            nupars_maxstart[i] = pfits[i]*1.01
        else:
            nupars_minstart[i] = pfits[i]*1.01
            nupars_maxstart[i] = pfits[i]*0.99

n_betpars = 4

nu_components = len(pfits)

ndims = 2 * n_betpars + nu_components + 5



minarr = np.zeros(ndims)
maxarr = np.zeros(ndims)
minarr[0] = bet0min
maxarr[0] = bet0max
minarr[1] = betinfmin
maxarr[1] = betinfmax
minarr[2] = betr0min
maxarr[2] = betr0max
minarr[3] = betnmin
maxarr[3] = betnmax

minarr[4] = bet0min
maxarr[4] = bet0max
minarr[5] = betinfmin
maxarr[5] = betinfmax
minarr[6] = betr0min
maxarr[6] = betr0max
minarr[7] = betnmin
maxarr[7] = betnmax

#minarr = np.delete(minarr, np.array([4, 5]))

logthis = [2, 6, 2*n_betpars+nu_components, 2*n_betpars+nu_components + 1]

#nupars_min[1:] = 0.1,2,5,0.1 - 1e-6

#nupars_max[1:] = 0.1,2,5,0.1 + 1e-6

minarr[2*n_betpars:2*n_betpars+nu_components] = nupars_min
maxarr[2*n_betpars:2*n_betpars+nu_components] = nupars_max
minarr[2*n_betpars+nu_components] = 5.0
maxarr[2*n_betpars+nu_components] = 10.0
minarr[2*n_betpars+nu_components+1] = np.log10(Rhalf / 2.0) 
maxarr[2*n_betpars+nu_components+1] = np.log10(Rhalf * 100.0)
minarr[2*n_betpars+nu_components+2] = 0.1
maxarr[2*n_betpars+nu_components+2] = 4.0
minarr[2*n_betpars+nu_components+3] = 3.1
maxarr[2*n_betpars+nu_components+3] = 7.0
minarr[2*n_betpars+nu_components+4] = 0.0
maxarr[2*n_betpars+nu_components+4] = 2.9
#minarr[2*n_betpars+nu_components*2+6] = Mstar_min
#maxarr[2*n_betpars+nu_components*2+6] = Mstar_max
#minarr[2*n_betpars+nu_components*2+6] = logMcenlow
#maxarr[2*n_betpars+nu_components*2+6] = logMcenhigh
#minarr[n_betpars+nu_components*2+7] = acenlow
#maxarr[n_betpars+nu_components*2+7] = acenhigh
#minarr[n_betpars+nu_components*2+8] = Arotlow
#maxarr[n_betpars+nu_components*2+8] = Arothigh
#minarr[n_betpars+nu_components*2+9] = drangelow
#maxarr[n_betpars+nu_components*2+9] = drangehigh


def ptform(u):
    
    x = np.array(u)

    #x[4:8] = x[:4] * (1 - 1e-6) + x[:4] * 1e-6
    
    return minarr + (maxarr - minarr) * x

if (barrad_min == 0):
        barrad_min = 1.0e-3
    
nu_rad = np.logspace(np.log10(barrad_min),\
                         np.log10(barrad_max), bar_pnts)

def lnprob(Theta):
            
    theta = np.copy(Theta)

    theta[0]= 2.0*theta[0]/(1 + theta[0])

    theta[1] = 2.0*theta[1]/(1 + theta[1])

    theta[4]= 2.0*theta[4]/(1 + theta[4])

    theta[5] = 2.0*theta[5]/(1 + theta[5])

    surc = theta[2*n_betpars: 2*n_betpars+nu_components]

    for i in logthis:
        
        theta[i] = 10**theta[i]

    rhobs = alpbetgamden(nu_rad, *surc)
    
    sobs = alpbetgamsurf(nu_rad, *surc, bar_pnts)
    
   # mobs = alpbetgammass(nu_rad, *surc)
    
   # mlum = np.max(mobs)
    
   # mobs *= 1/mlum
    
    def baranr(r):
        
        surf = np.interp(r,nu_rad,rhobs,right = 1e-30)
        
        return surf
    
    def barsurf(r):
        
        surf = np.interp(r,nu_rad,sobs,right = 1e-30)
        
        return surf
    
 #   def maser(r, mst):
        
       # surf = mst * np.interp(r,nu_rad,mobs)
        
#        return surf
    
    def M(r, Mparsu):
    
        Mpars = np.copy(Mparsu)

        rho0, r0, alp, bet, gam = Mpars

        return  alpbetgammass(r,rho0,r0,alp,bet,gam)

    Mpars = theta[2*n_betpars+nu_components:2*n_betpars+nu_components+5]

    betpars, betppars = theta[:4], theta[4:8]
    
    return lnlike_k(baranr,barsurf,M,beta,betaf, Mpars,\
                 betpars, betppars, rmin, rmax)



aau = np.linspace(1e-6, 100, 10**4) # 1.8 < k < 3.0
kku = 3.0 - (2 * aau**4/15) * (1 + aau**2/3)**(-2)
def asolveu(k):

    return np.interp(k, kku[::-1], aau[::-1])  

def lukpdf(x, var, kurt, err):

        sigma = var**0.5

        w = (x)/sigma
        werr = err/sigma

        a = asolveu(kurt)

        b = ((1 + a**2/3))**0.5

        t = np.sqrt(1.+b*b*werr*werr)

        delta, w0 = 0.0, 0.0
        
        am, ap = a-delta, a+delta
        it = 1./t
        bw = b*(w-w0)

        ln_pdf  = np.log(.5*b/a)+np.where((b*w+a)*it<0.,
                       logdiffexp(log_ndtr((bw+a)*it),log_ndtr((bw-a)*it)),
                        logdiffexp(log_ndtr(-(bw-a)*it),log_ndtr(-(bw+a)*it)),
                      )
        ln_pdf -= np.log(sigma)
        
        return ln_pdf

aal = np.linspace(1e-6, 100, 10**4) # 3.0 < k < 6.0
kkl = 3.0 + 12 * aal**4 * (2 * aal**2 + 1)**(-2)
def asolvel(k):

    return np.interp(k, kkl, aal)
   

def llkpdf(x, var, kurt, err):

    sigma = var**0.5

    w = (x)/sigma
    werr = err/sigma

    a = asolvel(kurt)

    b = (2 * a**2 + 1)**0.5

    delta, mean_w  = 0.0, 0.0

    t = np.sqrt(1.+b*b*werr*werr)
    
    ap = a+delta
    am = a-delta
    
    argU = (t*t-2*ap*b*(w-mean_w))
    positive_term = np.zeros_like(x)
    
    prefactor = np.log(b/(4.*ap))
    if type(kurt) is np.ndarray:
        prefactor = prefactor[argU<0.]
    positive_term[argU<0.] = prefactor+(argU/2./ap**2)[argU<0.]+\
                                lnerfc(((t*t-ap*b*(w-mean_w))/np.sqrt(2)/t/ap)[argU<0.])
    
    prefactor = np.log(b/ap)
    if type(kurt) is np.ndarray:
        prefactor = prefactor[argU>0.]
    positive_term[argU>0.]=.5*np.log(np.pi/8.)+prefactor+lnalpha((b*(w-mean_w)/t)[argU>0.])+\
                            lnerfcx(((t*t-ap*b*(w-mean_w))/np.sqrt(2)/t/ap)[argU>0.])
    
    argU = (t*t+2*am*b*(w-mean_w))
    negative_term = np.zeros_like(x)
    
    prefactor = np.log(b/(4.*am))
    if type(kurt) is np.ndarray:
        prefactor = prefactor[argU<0.]
    negative_term[argU<0.] = prefactor+(argU/2./am**2)[argU<0.]+\
                                lnerfc(((t*t+am*b*(w-mean_w))/np.sqrt(2)/t/am)[argU<0.])
    prefactor = np.log(b/am)
    if type(kurt) is np.ndarray:
        prefactor = prefactor[argU>0.]
    negative_term[argU>0.]=.5*np.log(np.pi/8.)+prefactor+lnalpha((b*(w-mean_w)/t)[argU>0.])+\
                            lnerfcx(((t*t+am*b*(w-mean_w))/np.sqrt(2)/t/am)[argU>0.])
    
    ln_pdf = np.logaddexp(positive_term,negative_term)-np.log(sigma)

    return ln_pdf


def lnpdfj(x, var, kurt, err):

     return np.select([kurt < 3.0, kurt >= 3.0], [lukpdf(x, var, kurt, err), llkpdf(x, var, kurt, err)])

rLOS, vLOS, vLOS_err, vPMt, vPMt_err, vPMR, vPMR_err  = np.loadtxt('10krltr_vels_plumcuspom.txt')

ss = np.argsort(rLOS)

sr = rLOS[ss]

# rcut = 5 * Rhalf

# for i in range(len(rLOS)):

#     if sr[i] >= rcut:

#         break
#i = -1
i = len(rLOS)

rLOS, vLOS, vLOS_err, vPMt, vPMt_err, vPMR, vPMR_err = rLOS[ss][:i], vLOS[ss][:i], vLOS_err[ss][:i], vPMt[ss][:i], vPMt_err[ss][:i], vPMR[ss][:i], vPMR_err[ss][:i]

vPMt_err, vPMR_err = vLOS_err, vLOS_err

#vLOS_err, vPMt_err, vPMR_err = 0.01 * vLOS_err / vLOS_err, 0.01 * vLOS_err / vLOS_err, 0.01 * vLOS_err / vLOS_err

rPM = rLOS

if (rmax < 0):
    rmin = Rhalf / 100.0
    rmax = Rhalf * 100.0
   

#rmin = Rhalf / 100.0

#rmax = 9.5

rcn = 50*Rhalf


def lnlike_prop_k(nu, Sigfunc,M,beta,betaf,Mpars,\
                 betpars, betppars, rmin,rmax):
    
    #theta = np.copy(Theta)
    
    Sigout, pmt2, pmr2, los2, kt, kr, kl = sigp_prop_k(R,rLOS,rPM,nu,Sigfunc,M,beta,betaf,Mpars,\
                  betpars, betppars, rmin,rmax, nonn = rcn)

    pmt2, pmr2, los2 = pmt2/1e6, pmr2/1e6, los2/1e6
    
    if np.isnan(np.sum(kl)) or np.isnan(np.sum(kt)) or np.isnan(np.sum(kr)):
    
         return -np.inf

    #kt, kr, kl = np.maximum(kt, 6.0), np.maximum(kr, 6.0), np.maximum(kl, 6.0) 

   # kt, kr, kl = np.minimum(kt, 1.8), np.minimum(kr, 1.8), np.minimum(kl, 1.8) 
    
    lnlike_out = np.sum(lnpdfj(vLOS, los2, kl, vLOS_err)) 
    lnlike_out += np.sum(lnpdfj(vPMt, pmt2, kt, vPMt_err)) + np.sum(lnpdfj(vPMR, pmr2, kr, vPMR_err))
    lnlike_out -= 0.5 * np.sum((surfden - Sigfunc(R))**2 / surfdenerr**2)

    if (lnlike_out != lnlike_out):
        lnlike_out = -np.inf
                    
    return lnlike_out

def lnlike_k(nu, Sigfunc,M,beta,betaf,Mpars,\
                 betpars, betppars, rmin,rmax):
    
   
    Sigout, los2, kl, neg = sigp_k(R,rLOS,nu,Sigfunc,M,beta,betaf,Mpars,\
                  betpars, betppars, rmin,rmax, nonn = rcn)
    
    los2 = los2/1e6
    
    if np.isnan(np.sum(kl)) or neg == True:
    
         return -np.inf

    
    lnlike_out = np.sum(lnpdfj(vLOS, los2, kl, vLOS_err))

    lnlike_out -= 0.5 * np.sum((surfden - Sigfunc(R))**2 / surfdenerr**2)

    if (lnlike_out != lnlike_out):
        lnlike_out = -np.inf
                    
    return lnlike_out




#Suppress warning output:
import warnings
warnings.simplefilter("ignore")

#Forbid plots to screen so GravSphere can run
#remotely:
import matplotlib as mpl
mpl.use('Agg')

